export const SEARCH_DATA = "SEARCH_DATA";
export const GET_DATA = "GET_DATA";
